import tkinter as tk
import os
import sys
import shutil
import json

window = tk.Tk()
window.title("BlitzOS Emulator")
window.configure(bg="black", cursor="none")
window.geometry("900x600")
window.attributes("-fullscreen", True)

DEFAULT_FONT = ("RuneScape UF", 25)
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
current_dir = SCRIPT_DIR

SYS_DIR = os.path.join(SCRIPT_DIR, "_sys")
os.makedirs(SYS_DIR, exist_ok=True)
CPU_FILE = os.path.join(SYS_DIR, "cpu.json")

terminal_frame = tk.Frame(window, bg="black")
terminal_frame.pack(fill="both", expand=True, padx=10, pady=10)

protected_mode = None
CPU = {}

if os.path.exists(CPU_FILE):
    try:
        with open(CPU_FILE, "r") as f:
            CPU = json.load(f)
    except Exception as e:
        CPU = {}

def saveCPU():
    try:
        os.makedirs(os.path.dirname(CPU_FILE), exist_ok=True)
        with open(CPU_FILE, "w") as f:
            json.dump(CPU, f)
    except Exception as e:
        terminalPrint(f"Error saving CPU JSON: {e}")

def terminalPrint(text):
    label = tk.Label(terminal_frame, text=text, font=DEFAULT_FONT, bg="black", fg="white", anchor="w")
    label.pack(anchor="w")

class TerminalStdout:
    def write(self, s):
        s = s.rstrip("\n")
        if s:
            terminalPrint(s)
    def flush(self):
        pass

editor_mode = False
editor_file_path = ""
editor_content = []

def is_protected(path):
    path = os.path.abspath(path)
    return "_sys" in path

def runFile(file_path):
    global current_dir, CPU
    if file_path.startswith("blitz"):
        file_path = file_path.replace("blitz", SCRIPT_DIR, 1)
    if not os.path.isabs(file_path):
        file_path = os.path.join(current_dir, file_path)
    if not os.path.exists(file_path):
        terminalPrint(f"File not found: {file_path}")
        return

    if file_path.endswith(".txt"):
        try:
            with open(file_path, "r") as f:
                content = f.read()
            terminalPrint(content)
        except Exception as e:
            terminalPrint(f"Error reading .txt file: {e}")
        return

    old_stdout = sys.stdout
    sys.stdout = TerminalStdout()
    try:
        with open(file_path, "r") as f:
            code = f.read()
        exec(code, {"CPU": CPU})
        saveCPU()
    except Exception as e:
        terminalPrint(f"Error running file: {e}")
    finally:
        sys.stdout = sys.__stdout__

def startEditor(file_path):
    global editor_mode, editor_file_path, editor_content
    editor_mode = True
    editor_file_path = file_path
    editor_content = []

    if file_path.startswith("blitz"):
        file_path = file_path.replace("blitz", SCRIPT_DIR, 1)

    if os.path.exists(file_path):
        with open(file_path, "r") as f:
            editor_content = f.read().splitlines()
    else:
        editor_content = []

    terminalPrint(f"Editing {file_path}. Type -e to exit editor.")
    addCommandLine(editor=True)

def exitEditor():
    global editor_mode, editor_file_path, editor_content
    if editor_file_path:
        os.makedirs(os.path.dirname(editor_file_path), exist_ok=True)
        with open(editor_file_path, "w") as f:
            f.write("\n".join(editor_content))
    terminalPrint(f"Saved {editor_file_path}")
    editor_mode = False
    editor_file_path = ""
    editor_content = []
    addCommandLine()

def executeCommand(cmd):
    global current_dir, protected_mode, CPU, editor_mode, editor_content
    parts = cmd.split()
    if not parts:
        addCommandLine(editor=editor_mode)
        return

    if editor_mode:
        if cmd.strip() == "-e":
            exitEditor()
        else:
            editor_content.append(cmd)
            addCommandLine(editor=True)
        return

    if protected_mode:
        if cmd.lower() == "yes":
            executeProtectedCommand()
        else:
            terminalPrint("Action cancelled.")
        protected_mode = None
        addCommandLine()
        return

    if parts[0] == "clear":
        for widget in terminal_frame.winfo_children():
            widget.destroy()
        addCommandLine()
        return

    if parts[0] == "pwd":
        terminalPrint(current_dir)
        addCommandLine()
        return

    if parts[0] == "files":
        target = current_dir
        recursive = False
        if len(parts) > 1:
            if parts[1] == "-r":
                recursive = True
                if len(parts) > 2:
                    target = parts[2]
            else:
                target = parts[1]
            if target.startswith("blitz"):
                target = target.replace("blitz", SCRIPT_DIR, 1)
            if not os.path.isabs(target):
                target = os.path.join(current_dir, target)
        if os.path.exists(target) and os.path.isdir(target):
            if recursive:
                for root, dirs, files in os.walk(target):
                    for d in dirs:
                        terminalPrint(os.path.join(root, d))
                    for f in files:
                        terminalPrint(os.path.join(root, f))
            else:
                for f in os.listdir(target):
                    terminalPrint(f)
        else:
            terminalPrint(f"No such directory: {target}")
        addCommandLine()
        return

    if parts[0] == "store" and "as" in parts:
        try:
            idx = parts.index("as")
            value = " ".join(parts[1:idx])
            name = " ".join(parts[idx+1:]).strip('"')
            try:
                value = int(value)
            except:
                try:
                    value = float(value)
                except:
                    pass
            CPU[name] = value
            saveCPU()
            terminalPrint(f"Stored {value} as CPU['{name}']")
        except Exception as e:
            terminalPrint(f"Error storing value: {e}")
        addCommandLine()
        return

    if "*e" in parts:
        file_path = parts[0]
        if file_path.startswith("blitz"):
            file_path = file_path.replace("blitz", SCRIPT_DIR, 1)
        if is_protected(file_path):
            terminalPrint("This folder is protected by BlitzOS. Are you sure you want to do anything in this folder?")
            protected_mode = {'cmd_type': 'edit', 'args': file_path}
            addCommandLine()
            return
        startEditor(file_path)
    elif parts[0] == "cd" and len(parts) > 1:
        target_dir = parts[1]
        if target_dir.startswith("blitz"):
            target_dir = target_dir.replace("blitz", SCRIPT_DIR, 1)
        new_dir = os.path.join(current_dir, target_dir) if not os.path.isabs(target_dir) else target_dir
        if is_protected(new_dir):
            terminalPrint("This folder is protected by BlitzOS. Are you sure you want to do anything in this folder?")
            protected_mode = {'cmd_type': 'cd', 'args': new_dir}
            addCommandLine()
            return
        if os.path.exists(new_dir) and os.path.isdir(new_dir):
            current_dir = new_dir
        else:
            terminalPrint(f"No such directory: {target_dir}")
        addCommandLine()
    elif parts[0] == "mkdir" and len(parts) > 1:
        folder_path = parts[1]
        if folder_path.startswith("blitz"):
            folder_path = folder_path.replace("blitz", SCRIPT_DIR, 1)
        full_path = os.path.join(current_dir, folder_path) if not os.path.isabs(folder_path) else folder_path
        if is_protected(full_path):
            terminalPrint("This folder is protected by BlitzOS. Are you sure you want to do anything in this folder?")
            protected_mode = {'cmd_type': 'mkdir', 'args': full_path}
            addCommandLine()
            return
        try:
            os.makedirs(full_path, exist_ok=True)
        except Exception as e:
            terminalPrint(f"Error creating folder: {e}")
        addCommandLine()
    elif parts[0] in ["rm", "del"] and len(parts) > 1:
        file_path = parts[1]
        if file_path.startswith("blitz"):
            file_path = file_path.replace("blitz", SCRIPT_DIR, 1)
        full_path = os.path.join(current_dir, file_path) if not os.path.isabs(file_path) else file_path
        if is_protected(full_path):
            terminalPrint("This folder is protected by BlitzOS. Are you sure you want to do anything in this folder?")
            protected_mode = {'cmd_type': 'delete', 'args': full_path}
            addCommandLine()
            return
        if os.path.exists(full_path):
            try:
                if os.path.isdir(full_path):
                    shutil.rmtree(full_path)
                else:
                    os.remove(full_path)
            except Exception as e:
                terminalPrint(f"Error deleting: {e}")
        else:
            terminalPrint(f"File not found: {file_path}")
        addCommandLine()
    else:
        if is_protected(parts[0]):
            terminalPrint("This folder is protected by BlitzOS. Are you sure you want to do anything in this folder?")
            protected_mode = {'cmd_type': 'run', 'args': parts[0]}
            addCommandLine()
            return
        runFile(cmd)
        addCommandLine()

def addCommandLine(editor=False):
    frame = tk.Frame(terminal_frame, bg="black")
    frame.pack(anchor="w", pady=2, fill="x")

    prompt_label = tk.Label(frame, text="EDIT> " if editor else "BLITZ> ", font=DEFAULT_FONT, bg="black", fg="white")
    prompt_label.pack(side="left")

    entry = tk.Text(frame, font=DEFAULT_FONT, bg="black", fg="white", height=1, bd=0, highlightthickness=0, insertontime=0)
    entry.pack(side="left", fill="x", expand=True)
    entry.focus_set()

    def handleReturn(event):
        cmd = entry.get("1.0", "end-1c")
        frame.destroy()
        terminalPrint(f"{'EDIT' if editor else 'BLITZ'}> {cmd}")
        executeCommand(cmd)
        return "break"

    entry.bind("<Return>", handleReturn)

addCommandLine()
window.mainloop()
