-- WELCOME TO BLITZ OS --
-------------------------------------------------------------------------------------
BLITZ OS IS A VIRTUAL COMPUTER USING PYTHON. THIS PROGRAM WAS 100% MADE TO TEST MY CODING SKILLS. THIS IS NOT <REAL> OPERATING SYSTEM. YOU CAN RUN THIS ON THE FOLLOWING OPERATING SYSTEMS (EXCEPT FOR BLITZ OS ITSELF AND MANY MORE): MAC OS, WINDOWS OS, LINUX, AND WAY MORE. THIS PROGRAM IS <NOT> LICENSED AND CAN BE USED BY ANYTHING. BEFORE USING THE PROGRAM PLEASE
INSTALL THE _sys/_fonts/_main-font.tff PLEASE.
-------------------------------------------------------------------------------------
=================================== INFO ============================================
-------------------------------------------------------------------------------------
ANY FOLDER OR FILE THAT STARTS WITH _ IS <RESERVED> FOR THE SYSTEM AND MORE. THIS PROGRAM WAS MADE WITH PYTHON VERSION 3.14. THIS IS THE FIRST VERSION OF THE BLITZ OS PROGRAM WHICH IS VERSION 1.0.0. BLTIZ OS IS JUST A PLAIN TERMINAL / SHELL. THE DESKTOP OR EXPLORER WILL BE CREATED IN A LATER VERSION (1.0.4) OR HIGHER.
-------------------------------------------------------------------------------------
=================================== LINKS ===========================================
-------------------------------------------------------------------------------------

GITHUB PROJECT: github.com/notlbock/BlitzOS


|      |
|      |

|       |
|_______|
